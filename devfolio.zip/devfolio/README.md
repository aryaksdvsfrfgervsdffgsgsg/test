# Arya Kond Reddy — Developer Portfolio

A responsive single-page developer portfolio built with semantic HTML and CSS. It showcases my learning journey, course projects, and contact information.

## Features

- Semantic HTML structure with `header`, `nav`, `main`, `section`, and `footer`
- Responsive navigation
- CSS variables for a consistent colour system
- Flexbox for navigation and footer layouts
- CSS Grid for responsive project cards
- Mobile-first responsive design
- Working email and GitHub contact links
- No build tools or dependencies required

## Project Structure

```text
devfolio/
├── index.html
├── style.css
└── README.md
```

## Run Locally

1. Download or clone this repository.
2. Open the project folder.
3. Open `index.html` in a browser.

No installation or build command is required.

## GitHub Pages

This project is designed to deploy directly through GitHub Pages.

Recommended GitHub Pages settings:

1. Open the repository on GitHub.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and the `/ (root)` folder.
5. Save and wait for the deployment to complete.

### Live URL

After GitHub Pages is enabled, the expected URL is:

`https://aryaksdvsfrfgervsdffgsgsg.github.io/devfolio/`

If the repository name is changed, update this URL accordingly.

## Contact

- Email: reddykvkp@gmail.com
- GitHub: https://github.com/aryaksdvsfrfgervsdffgsgsg

LinkedIn is intentionally omitted.
